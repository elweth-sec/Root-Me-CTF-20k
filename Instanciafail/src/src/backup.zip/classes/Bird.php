<?php
require_once 'Animal.php';

class Bird extends Animal {
    public function speak() {
        return "Tweet";
    }
}
?>
