<?php
require_once 'Animal.php';

class Hamster extends Animal {
    public function speak() {
        return "Squeak";
    }
}
?>
