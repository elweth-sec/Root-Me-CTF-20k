<?php
require_once 'Animal.php';

class Rabbit extends Animal {
    public function speak() {
        return "Boouh";
    }
}
?>
