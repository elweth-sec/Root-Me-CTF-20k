<?php
define('DB_HOST', 'db');
define('DB_USER', 'user');
define('DB_PASS', 'password');
define('DB_NAME', 'animalerie');
?>