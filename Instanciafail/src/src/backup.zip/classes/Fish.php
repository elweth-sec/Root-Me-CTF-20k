<?php
require_once 'Animal.php';

class Fish extends Animal {
    public function speak() {
        return "Blub";
    }
}
?>
