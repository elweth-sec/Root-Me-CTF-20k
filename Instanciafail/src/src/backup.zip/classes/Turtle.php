<?php
require_once 'Animal.php';

class Turtle extends Animal {
    public function speak() {
        return "AH";
    }
}
?>
